import 'package:caterease/features/restaurants/domain/entities/restaurant.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:caterease/features/restaurants/presentation/bloc/restaurants_bloc.dart';
import 'package:caterease/features/restaurants/presentation/widgets/restaurant_card.dart';

class CategoryRestaurantsPage extends StatelessWidget {
  final String category;

  const CategoryRestaurantsPage({Key? key, required this.category})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Trigger the API call on load
    context
        .read<RestaurantsBloc>()
        .add(GetRestaurantsByCategoryEvent(category));

    return Scaffold(
      appBar: AppBar(
        title: Text('$category Restaurants'),
        centerTitle: true,
      ),
      body: BlocBuilder<RestaurantsBloc, RestaurantsState>(
        builder: (context, state) {
          if (state is RestaurantsLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is RestaurantsByCategoryLoaded) {
            final branches = state.restaurants;

            if (branches.isEmpty) {
              return const Center(child: Text('No restaurants found.'));
            }

            return ListView.builder(
              itemCount: branches.length,
              itemBuilder: (context, index) {
                final branch = branches[index];
                return RestaurantCard(
                  restaurant: Restaurant(
                    id: branch.branchId,
                    name: branch.restaurant,
                    description: branch.description,
                    photo:
                        "https://via.placeholder.com/300", // صورة افتراضية مؤقتة
                    rating: 4.5, // تقييم افتراضي مؤقت
                    totalRatings: 200, // عدد تقييمات افتراضي مؤقت
                    distance: branch.distanceKm,
                    city: null, // مافي city حالياً بالبيانات
                  ),
                );
              },
            );
          } else if (state is RestaurantsError) {
            return Center(child: Text('Error: ${state.message}'));
          }

          return const SizedBox.shrink();
        },
      ),
    );
  }
}
