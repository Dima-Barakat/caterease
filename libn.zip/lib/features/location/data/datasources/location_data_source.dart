import "package:geolocator/geolocator.dart";
import "package:permission_handler/permission_handler.dart";
import 'package:http/http.dart' as http;
import 'dart:convert';

abstract class LocationDataSource {
  Future<Position> getCurrentLocation();
  Future<bool> requestPermission();
}

class LocationDataSourceImpl implements LocationDataSource {
  final String token; // التوكين من AuthBloc
  Position? _lastPosition;

  LocationDataSourceImpl({required this.token});

  @override
  Future<Position> getCurrentLocation() async {
    final newPosition = await Geolocator.getCurrentPosition(
      desiredAccuracy: LocationAccuracy.high,
    );

    if (_lastPosition == null) {
      _lastPosition = newPosition;
      await _sendDefaultAddress(newPosition); // إرسال الموقع أول مرة
      return newPosition;
    }

    final distance = Geolocator.distanceBetween(
      _lastPosition!.latitude,
      _lastPosition!.longitude,
      newPosition.latitude,
      newPosition.longitude,
    );

    if (distance > 500) {
      _lastPosition = newPosition;
      await _sendDefaultAddress(newPosition); // إرسال إذا تحرك >500m
    }

    return _lastPosition!;
  }

  Future<void> _sendDefaultAddress(Position position) async {
    try {
      final response = await http.post(
        Uri.parse('http://127.0.0.1:8000/api/customer/addresses/4/default'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode({
          'latitude': position.latitude,
          'longitude': position.longitude,
        }),
      );

      if (response.statusCode != 200) {
        throw Exception('Failed to update default address');
      }
    } catch (e) {
      print('Error sending address: $e');
      rethrow; // لإدارة الخطأ في الـ Bloc
    }
  }

  @override
  Future<bool> requestPermission() async {
    var status = await Permission.locationWhenInUse.request();
    return status.isGranted;
  }
}
