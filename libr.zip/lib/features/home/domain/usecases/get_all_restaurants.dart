import 'package:caterease/core/errors/failures.dart';
import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:caterease/features/home/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';

class GetAllRestaurants {
  final HomeRepository repository;

  GetAllRestaurants(this.repository);

  Future<Either<Failure, List<RestaurantEntity>>> call() {
    return repository.getAllRestaurants();
  }
}

