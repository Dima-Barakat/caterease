import 'package:equatable/equatable.dart';

class RestaurantEntity extends Equatable {
  final int id;
  final String name;
  final String photo;
  final String description;
  final double rating;
  final int totalRatings;
  final double? distance;

  const RestaurantEntity({
    required this.id,
    required this.name,
    required this.photo,
    required this.description,
    required this.rating,
    required this.totalRatings,
    this.distance,
  });

  @override
  List<Object?> get props => [
        id,
        name,
        photo,
        description,
        rating,
        totalRatings,
        distance,
      ];
}
