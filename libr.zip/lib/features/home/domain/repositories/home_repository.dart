import 'package:caterease/core/errors/failures.dart';
import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:dartz/dartz.dart';

abstract class HomeRepository {
  Future<Either<Failure, List<RestaurantEntity>>> getNearbyRestaurants(double lat, double lng);
  Future<Either<Failure, List<RestaurantEntity>>> getAllRestaurants();
}

