import 'package:caterease/core/constants/app_constants.dart';
import 'package:caterease/core/errors/exceptions.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

abstract class HomeRemoteDataSource {
  Future<List<Map<String, dynamic>>> getNearbyRestaurants(double lat, double lng);
  Future<List<Map<String, dynamic>>> getAllRestaurants();
}

class HomeRemoteDataSourceImpl implements HomeRemoteDataSource {
  final http.Client client;

  HomeRemoteDataSourceImpl({required this.client});

  @override
  Future<List<Map<String, dynamic>>> getNearbyRestaurants(double lat, double lng) async {
    final response = await client.get(
      Uri.parse('${AppConstants.baseUrl}/branches/nearby?lat=$lat&lng=$lng'),
    );

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(json.decode(response.body)['data']);
    } else {
      throw ServerException('Failed to load nearby restaurants');
    }
  }

  @override
  Future<List<Map<String, dynamic>>> getAllRestaurants() async {
    final response = await client.get(
      Uri.parse('${AppConstants.baseUrl}/restaurants'),
    );

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(json.decode(response.body));
    } else {
      throw ServerException('Failed to load all restaurants');
    }
  }
}

