import 'package:caterease/core/errors/exceptions.dart';
import 'package:caterease/core/errors/failures.dart';
import 'package:caterease/core/network/network_info.dart';
import 'package:caterease/features/home/data/datasources/home_remote_data_source.dart';
import 'package:caterease/features/home/data/models/restaurant_model.dart';
import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:caterease/features/home/domain/repositories/home_repository.dart';
import 'package:dartz/dartz.dart';

class HomeRepositoryImpl implements HomeRepository {
  final HomeRemoteDataSource remoteDataSource;
  final NetworkInfo networkInfo;

  HomeRepositoryImpl({
    required this.remoteDataSource,
    required this.networkInfo,
  });

  @override
  Future<Either<Failure, List<RestaurantEntity>>> getNearbyRestaurants(
      double lat, double lng) async {
    if (!await networkInfo.isConnected) {
      return Left(ServerFailure('No Internet connection'));
    }

    try {
      final restaurants = await remoteDataSource.getNearbyRestaurants(lat, lng);
      return Right(
          restaurants.map((e) => RestaurantModel.fromJson(e)).toList());
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }

  @override
  Future<Either<Failure, List<RestaurantEntity>>> getAllRestaurants() async {
    if (!await networkInfo.isConnected) {
      return Left(ServerFailure('No Internet connection'));
    }

    try {
      final restaurants = await remoteDataSource.getAllRestaurants();
      return Right(
          restaurants.map((e) => RestaurantModel.fromJson(e)).toList());
    } on ServerException catch (e) {
      return Left(ServerFailure(e.message));
    }
  }
}
