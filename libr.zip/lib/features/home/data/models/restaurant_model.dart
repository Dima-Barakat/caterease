import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';

class RestaurantModel extends RestaurantEntity {
  const RestaurantModel({
    required super.id,
    required super.name,
    required super.photo,
    required super.description,
    required super.rating,
    required super.totalRatings,
    super.distance,
  });

  factory RestaurantModel.fromJson(Map<String, dynamic> json) {
    return RestaurantModel(
      id: json["restaurant_id"] ?? json["id"],
      name: json["name"],
      photo: json["photo"],
      description: json["description"],
      rating: (json["rating"] ?? 0).toDouble(),
      totalRatings: json["total_ratings"] ?? 0,
      distance: json["distance"]?.toDouble(),
    );
  }

  @override
  List<Object?> get props => [
        id,
        name,
        photo,
        description,
        rating,
        totalRatings,
        distance,
      ];
}


