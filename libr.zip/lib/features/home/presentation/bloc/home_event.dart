part of 'home_bloc.dart';

abstract class HomeEvent extends Equatable {
  const HomeEvent();

  @override
  List<Object> get props => [];
}

class LoadNearbyRestaurants extends HomeEvent {
  final double lat;
  final double lng;

  const LoadNearbyRestaurants({required this.lat, required this.lng});

  @override
  List<Object> get props => [lat, lng];
}

class LoadAllRestaurants extends HomeEvent {
  const LoadAllRestaurants();
}

