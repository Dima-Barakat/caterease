part of 'home_bloc.dart';

abstract class HomeState extends Equatable {
  final List<RestaurantEntity> nearbyRestaurants;
  final List<RestaurantEntity> allRestaurants;

  const HomeState({
    this.nearbyRestaurants = const [],
    this.allRestaurants = const [],
  });

  @override
  List<Object> get props => [nearbyRestaurants, allRestaurants];
}

class HomeInitial extends HomeState {
  const HomeInitial() : super(nearbyRestaurants: const [], allRestaurants: const []);
}

class HomeLoading extends HomeState {
  const HomeLoading() : super(nearbyRestaurants: const [], allRestaurants: const []);
}

class HomeLoaded extends HomeState {
  const HomeLoaded({
    required List<RestaurantEntity> nearbyRestaurants,
    required List<RestaurantEntity> allRestaurants,
  }) : super(nearbyRestaurants: nearbyRestaurants, allRestaurants: allRestaurants);
}

class HomeError extends HomeState {
  final String message;

  const HomeError({required this.message}) : super(nearbyRestaurants: const [], allRestaurants: const []);

  @override
  List<Object> get props => [message];
}


