import 'package:bloc/bloc.dart';
import 'package:caterease/core/errors/failures.dart';
import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:caterease/features/home/domain/usecases/get_all_restaurants.dart';
import 'package:caterease/features/home/domain/usecases/get_nearby_restaurants.dart';
import 'package:equatable/equatable.dart';
part 'home_event.dart';
part 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final GetNearbyRestaurants getNearbyRestaurants;
  final GetAllRestaurants getAllRestaurants;

  HomeBloc({
    required this.getNearbyRestaurants,
    required this.getAllRestaurants,
  }) : super(HomeInitial()) {
    on<LoadNearbyRestaurants>(_onLoadNearbyRestaurants);
    on<LoadAllRestaurants>(_onLoadAllRestaurants);
  }

  Future<void> _onLoadNearbyRestaurants(
    LoadNearbyRestaurants event,
    Emitter<HomeState> emit,
  ) async {
    emit(HomeLoading());
    final result = await getNearbyRestaurants(event.lat, event.lng);
    result.fold(
      (failure) => emit(HomeError(message: _mapFailureToMessage(failure))),
      (restaurants) => emit(HomeLoaded(
        nearbyRestaurants: restaurants,
        allRestaurants: state.allRestaurants,
      )),
    );
  }

  Future<void> _onLoadAllRestaurants(
    LoadAllRestaurants event,
    Emitter<HomeState> emit,
  ) async {
    emit(HomeLoading());
    final result = await getAllRestaurants();
    result.fold(
      (failure) => emit(HomeError(message: _mapFailureToMessage(failure))),
      (restaurants) => emit(HomeLoaded(
        nearbyRestaurants: state.nearbyRestaurants,
        allRestaurants: restaurants,
      )),
    );
  }

  String _mapFailureToMessage(Failure failure) {
    switch (failure.runtimeType) {
      case ServerFailure:
        return 'Server Error';
      default:
        return 'Unexpected Error';
    }
  }
}
