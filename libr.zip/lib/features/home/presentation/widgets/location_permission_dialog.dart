import 'package:flutter/material.dart';

class LocationPermissionDialog extends StatelessWidget {
  final VoidCallback onAllow;
  final VoidCallback onDeny;

  const LocationPermissionDialog({
    super.key,
    required this.onAllow,
    required this.onDeny,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Location Permission Needed'),
      content: const Text('We need your location to show nearby restaurants'),
      actions: [
        TextButton(
          onPressed: onDeny,
          child: const Text('Deny'),
        ),
        TextButton(
          onPressed: onAllow,
          child: const Text('Allow'),
        ),
      ],
    );
  }
}

