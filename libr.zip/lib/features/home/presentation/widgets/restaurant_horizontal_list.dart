import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:caterease/features/home/presentation/widgets/restaurant_card.dart';
import 'package:flutter/material.dart';

class RestaurantHorizontalList extends StatelessWidget {
  final List<RestaurantEntity> restaurants;
  
  const RestaurantHorizontalList({super.key, required this.restaurants});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 200,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: restaurants.length,
        itemBuilder: (context, index) {
          return RestaurantCard(restaurant: restaurants[index]);
        },
      ),
    );
  }
}

