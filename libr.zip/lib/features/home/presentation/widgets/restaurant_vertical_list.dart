import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:caterease/features/home/presentation/widgets/restaurant_card.dart';
import 'package:flutter/material.dart';

class RestaurantVerticalList extends StatelessWidget {
  final List<RestaurantEntity> restaurants;
  
  const RestaurantVerticalList({super.key, required this.restaurants});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: restaurants.length,
      itemBuilder: (context, index) {
        return RestaurantCard(restaurant: restaurants[index]);
      },
    );
  }
}

