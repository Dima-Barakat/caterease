import 'package:caterease/features/home/domain/entities/restaurant_entity.dart';
import 'package:flutter/material.dart';

class RestaurantCard extends StatelessWidget {
  final RestaurantEntity restaurant;
  
  const RestaurantCard({super.key, required this.restaurant});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Column(
        children: [
          Image.network(restaurant.photo),
          Text(restaurant.name),
          Text('${restaurant.rating} ⭐'),
        ],
      ),
    );
  }
}

