import 'package:caterease/core/utils/location_utils.dart';
import 'package:caterease/features/home/presentation/bloc/home_bloc.dart';
import 'package:caterease/features/home/presentation/widgets/category_chip.dart';
import 'package:caterease/features/home/presentation/widgets/location_permission_dialog.dart';
import 'package:caterease/features/home/presentation/widgets/restaurant_horizontal_list.dart';
import 'package:caterease/features/home/presentation/widgets/restaurant_vertical_list.dart';
import 'package:caterease/features/home/presentation/widgets/section_header.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geolocator/geolocator.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    _checkLocationPermission();
  }

  Future<void> _checkLocationPermission() async {
    LocationPermission permission = await LocationUtils.checkLocationPermission();
    if (permission == LocationPermission.denied) {
      _showLocationPermissionDialog();
    } else if (permission == LocationPermission.deniedForever) {
      // Handle denied forever case, maybe open app settings
    } else {
      _loadNearbyRestaurants();
    }
  }

  void _showLocationPermissionDialog() {
    showDialog(
      context: context,
      builder: (context) => LocationPermissionDialog(
        onAllow: () async {
          Navigator.of(context).pop();
          LocationPermission permission = await Geolocator.requestPermission();
          if (permission == LocationPermission.whileInUse ||
              permission == LocationPermission.always) {
            _loadNearbyRestaurants();
          }
        },
        onDeny: () {
          Navigator.of(context).pop();
          // Handle denial, maybe load all restaurants instead
          context.read<HomeBloc>().add(const LoadAllRestaurants());
        },
      ),
    );
  }

  Future<void> _loadNearbyRestaurants() async {
    try {
      Position position = await LocationUtils.getCurrentPosition();
      context.read<HomeBloc>().add(
            LoadNearbyRestaurants(
              lat: position.latitude,
              lng: position.longitude,
            ),
          );
    } catch (e) {
      // Handle error getting location, maybe load all restaurants
      context.read<HomeBloc>().add(const LoadAllRestaurants());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("CaterEase"),
      ),
      body: BlocBuilder<HomeBloc, HomeState>(
        builder: (context, state) {
          if (state is HomeLoading) {
            return const Center(child: CircularProgressIndicator());
          } else if (state is HomeLoaded) {
            return SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader(title: "Categories"),
                  SizedBox(
                    height: 50,
                    child: ListView(
                      scrollDirection: Axis.horizontal,
                      children: const [
                        CategoryChip(label: "Fast Food"),
                        CategoryChip(label: "Desserts"),
                        CategoryChip(label: "Drinks"),
                        CategoryChip(label: "Healthy"),
                        CategoryChip(label: "Vegetarian"),
                      ],
                    ),
                  ),
                  if (state.nearbyRestaurants.isNotEmpty)
                    SectionHeader(title: "Nearby Restaurants"),
                  if (state.nearbyRestaurants.isNotEmpty)
                    RestaurantHorizontalList(
                        restaurants: state.nearbyRestaurants),
                  if (state.allRestaurants.isNotEmpty)
                    SectionHeader(title: "All Restaurants"),
                  if (state.allRestaurants.isNotEmpty)
                    RestaurantVerticalList(
                        restaurants: state.allRestaurants),
                ],
              ),
            );
          } else if (state is HomeError) {
            return Center(child: Text(state.message));
          }
          return const Center(child: Text("Welcome to CaterEase!"));
        },
      ),
    );
  }
}

