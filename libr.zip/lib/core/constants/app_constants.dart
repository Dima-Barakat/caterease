class AppConstants {
  static const String baseUrl = 'http://192.168.198.155:8000//api';
}
