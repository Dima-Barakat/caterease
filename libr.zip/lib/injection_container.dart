import 'package:caterease/core/network/network_info.dart';
import 'package:caterease/features/home/data/datasources/home_remote_data_source.dart';
import 'package:caterease/features/home/data/repositories/home_repository_impl.dart';
import 'package:caterease/features/home/domain/repositories/home_repository.dart';
import 'package:caterease/features/home/domain/usecases/get_all_restaurants.dart';
import 'package:caterease/features/home/domain/usecases/get_nearby_restaurants.dart';
import 'package:caterease/features/home/presentation/bloc/home_bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;
import 'package:internet_connection_checker/internet_connection_checker.dart';

final sl = GetIt.instance;

Future<void> init() async {
  //! External
  sl.registerLazySingleton(() => http.Client());
  sl.registerLazySingleton<InternetConnectionChecker>(
    () => InternetConnectionChecker.createInstance(),
  );

  //! Core
  sl.registerLazySingleton<NetworkInfo>(
    () => NetworkInfoImpl(sl()),
  );

  //! Features - Home
  // Data Sources
  sl.registerLazySingleton<HomeRemoteDataSource>(
    () => HomeRemoteDataSourceImpl(client: sl()),
  );

  // Repository
  sl.registerLazySingleton<HomeRepository>(
    () => HomeRepositoryImpl(
      remoteDataSource: sl(),
      networkInfo: sl(),
    ),
  );

  // Use Cases
  sl.registerLazySingleton(() => GetNearbyRestaurants(sl()));
  sl.registerLazySingleton(() => GetAllRestaurants(sl()));

  // BLoC
  sl.registerFactory(() => HomeBloc(
        getNearbyRestaurants: sl(),
        getAllRestaurants: sl(),
      ));
}
