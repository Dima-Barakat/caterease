class ApiConstants {
  static const String baseUrl = 'http://192.168.43.2:8000/api';
  static const String nearbyBranches = '/branches/nearby';
  static const String restaurants = '/restaurants';
}
