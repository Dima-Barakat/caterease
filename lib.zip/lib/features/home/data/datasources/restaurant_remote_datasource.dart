import '../models/restaurant_model.dart';
import '../models/location_model.dart';
import '../models/category_model.dart';
import '../../../../core/network/api_client.dart';

abstract class RestaurantRemoteDataSource {
  Future<List<RestaurantModel>> getNearbyRestaurants(LocationModel location);
  Future<List<CategoryModel>> getCategories();
  Future<List<RestaurantModel>> getRestaurantsByCategory(String categoryId);
}

class RestaurantRemoteDataSourceImpl implements RestaurantRemoteDataSource {
  final ApiClient apiClient;

  RestaurantRemoteDataSourceImpl({required this.apiClient});

  @override
  Future<List<RestaurantModel>> getNearbyRestaurants(LocationModel location) async {
    try {
      final response = await apiClient.get(
        '/restaurants/nearby?lat=${location.latitude}&lng=${location.longitude}',
      );

      final List<dynamic> restaurantsJson = response['data'] ?? [];
      return restaurantsJson
          .map((json) => RestaurantModel.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch nearby restaurants: $e');
    }
  }

  @override
  Future<List<CategoryModel>> getCategories() async {
    try {
      final response = await apiClient.get('/categories');

      final List<dynamic> categoriesJson = response['data'] ?? [];
      return categoriesJson
          .map((json) => CategoryModel.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch categories: $e');
    }
  }

  @override
  Future<List<RestaurantModel>> getRestaurantsByCategory(String categoryId) async {
    try {
      final response = await apiClient.get('/restaurants/category/$categoryId');

      final List<dynamic> restaurantsJson = response['data'] ?? [];
      return restaurantsJson
          .map((json) => RestaurantModel.fromJson(json))
          .toList();
    } catch (e) {
      throw Exception('Failed to fetch restaurants by category: $e');
    }
  }
}

