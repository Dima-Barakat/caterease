import '../../domain/entities/restaurant.dart';
import '../../domain/entities/location.dart';
import '../../domain/entities/category.dart';
import '../../domain/repositories/restaurant_repository.dart';
import '../datasources/restaurant_remote_datasource.dart';
import '../models/location_model.dart';

class RestaurantRepositoryImpl implements RestaurantRepository {
  final RestaurantRemoteDataSource remoteDataSource;

  RestaurantRepositoryImpl({required this.remoteDataSource});

  @override
  Future<List<Restaurant>> getNearbyRestaurants(Location location) async {
    try {
      final locationModel = LocationModel(
        latitude: location.latitude,
        longitude: location.longitude,
        address: location.address,
      );
      
      return await remoteDataSource.getNearbyRestaurants(locationModel);
    } catch (e) {
      throw Exception('Failed to get nearby restaurants: $e');
    }
  }

  @override
  Future<List<Category>> getCategories() async {
    try {
      return await remoteDataSource.getCategories();
    } catch (e) {
      throw Exception('Failed to get categories: $e');
    }
  }

  @override
  Future<List<Restaurant>> getRestaurantsByCategory(String categoryId) async {
    try {
      return await remoteDataSource.getRestaurantsByCategory(categoryId);
    } catch (e) {
      throw Exception('Failed to get restaurants by category: $e');
    }
  }
}

