import '../../domain/entities/location.dart';
import '../../domain/repositories/location_repository.dart';
import '../datasources/location_local_datasource.dart';

class LocationRepositoryImpl implements LocationRepository {
  final LocationLocalDataSource localDataSource;

  LocationRepositoryImpl({required this.localDataSource});

  @override
  Future<Location> getCurrentLocation() async {
    try {
      return await localDataSource.getCurrentLocation();
    } catch (e) {
      throw Exception('Failed to get current location: $e');
    }
  }

  @override
  Future<bool> isLocationPermissionGranted() async {
    try {
      return await localDataSource.isLocationPermissionGranted();
    } catch (e) {
      throw Exception('Failed to check location permission: $e');
    }
  }

  @override
  Future<bool> requestLocationPermission() async {
    try {
      return await localDataSource.requestLocationPermission();
    } catch (e) {
      throw Exception('Failed to request location permission: $e');
    }
  }
}

