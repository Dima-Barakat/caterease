import '../entities/location.dart';

abstract class LocationRepository {
  Future<Location> getCurrentLocation();
  Future<bool> isLocationPermissionGranted();
  Future<bool> requestLocationPermission();
}

