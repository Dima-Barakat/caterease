import '../entities/restaurant.dart';
import '../entities/location.dart';
import '../entities/category.dart';

abstract class RestaurantRepository {
  Future<List<Restaurant>> getNearbyRestaurants(Location location);
  Future<List<Category>> getCategories();
  Future<List<Restaurant>> getRestaurantsByCategory(String categoryId);
}

