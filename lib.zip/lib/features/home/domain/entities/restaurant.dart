class Restaurant {
  final String id;
  final String name;
  final String description;
  final String imageUrl;
  final double rating;
  final String category;
  final double distance;
  final String address;
  final bool isFavorite;
  final List<String> tags;

  const Restaurant({
    required this.id,
    required this.name,
    required this.description,
    required this.imageUrl,
    required this.rating,
    required this.category,
    required this.distance,
    required this.address,
    this.isFavorite = false,
    this.tags = const [],
  });
}

