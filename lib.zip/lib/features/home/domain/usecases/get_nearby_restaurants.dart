import '../entities/restaurant.dart';
import '../entities/location.dart';
import '../repositories/restaurant_repository.dart';

class GetNearbyRestaurants {
  final RestaurantRepository repository;

  GetNearbyRestaurants(this.repository);

  Future<List<Restaurant>> call(Location location) async {
    return await repository.getNearbyRestaurants(location);
  }
}

