import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../bloc/home_bloc.dart';
import '../bloc/home_event.dart';
import '../bloc/home_state.dart';
import '../widgets/category_card.dart';
import '../widgets/restaurant_card.dart';
import '../../../../core/constants/colors.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    context.read<HomeBloc>().add(LoadHomeData());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kColorWhite,
      body: SafeArea(
        child: BlocConsumer<HomeBloc, HomeState>(
          listener: (context, state) {
            if (state is LocationPermissionRequested) {
              _showLocationPermissionDialog(context);
            } else if (state is LocationPermissionDenied) {
              _showLocationDeniedSnackBar(context);
            } else if (state is HomeError) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(state.message),
                  backgroundColor: Colors.red,
                ),
              );
            }
          },
          builder: (context, state) {
            return CustomScrollView(
              slivers: [
                _buildAppBar(),
                if (state is HomeLoading) _buildLoadingState(),
                if (state is HomeLoaded) ...[
                  _buildSearchBar(),
                  _buildCategoriesSection(state.categories),
                  _buildFavoritesSection(),
                  _buildRestaurantsSection(state.restaurants),
                ],
                if (state is LocationPermissionDenied) _buildLocationDeniedState(),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      backgroundColor: kColorWhite,
      elevation: 0,
      floating: true,
      pinned: false,
      title: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.menu, color: kColorDarkBlue),
            onPressed: () {},
          ),
          const Spacer(),
          IconButton(
            icon: const Icon(Icons.notifications_outlined, color: kColorDarkBlue),
            onPressed: () {},
          ),
          const CircleAvatar(
            radius: 18,
            backgroundColor: kColorLightGray,
            child: Icon(Icons.person, color: kColorDarkBlue),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchBar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          decoration: BoxDecoration(
            color: kColorLightGray,
            borderRadius: BorderRadius.circular(12),
          ),
          child: TextField(
            decoration: InputDecoration(
              hintText: 'Search',
              hintStyle: TextStyle(color: kColorDarkBlue.withOpacity(0.6)),
              prefixIcon: Icon(Icons.search, color: kColorDarkBlue.withOpacity(0.6)),
              suffixIcon: Icon(Icons.mic, color: kColorDarkBlue.withOpacity(0.6)),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCategoriesSection(categories) {
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Categories',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kColorDarkBlue,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: const Text(
                    'View all',
                    style: TextStyle(color: kColorDarkBlue),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: 100,
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              scrollDirection: Axis.horizontal,
              itemCount: categories.length,
              itemBuilder: (context, index) {
                return CategoryCard(
                  category: categories[index],
                  onTap: () {
                    // Handle category tap
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFavoritesSection() {
    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFE91E63), Color(0xFF9C27B0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Shish and Kafta',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: kColorWhite,
                    ),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'See our wide range of delicious food',
                    style: TextStyle(
                      fontSize: 14,
                      color: kColorWhite,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: kColorWhite.withOpacity(0.2),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.restaurant_menu,
                color: kColorWhite,
                size: 30,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRestaurantsSection(restaurants) {
    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Season Specials',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: kColorDarkBlue,
                  ),
                ),
                TextButton(
                  onPressed: () {},
                  child: const Text(
                    'View all',
                    style: TextStyle(color: kColorDarkBlue),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: restaurants.length,
            itemBuilder: (context, index) {
              return RestaurantCard(
                restaurant: restaurants[index],
                onTap: () {
                  // Handle restaurant tap
                },
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return const SliverFillRemaining(
      child: Center(
        child: CircularProgressIndicator(
          color: kColorDarkBlue,
        ),
      ),
    );
  }

  Widget _buildLocationDeniedState() {
    return SliverFillRemaining(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.location_off,
              size: 64,
              color: kColorDarkBlue,
            ),
            const SizedBox(height: 16),
            const Text(
              'Location Permission Denied',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: kColorDarkBlue,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Please enable location permission to see nearby restaurants',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 14,
                color: kColorDarkBlue,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                context.read<HomeBloc>().add(RequestLocationPermissionEvent());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: kColorDarkBlue,
                foregroundColor: kColorWhite,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
              child: const Text('Request Permission'),
            ),
          ],
        ),
      ),
    );
  }

  void _showLocationPermissionDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Location Permission'),
          content: const Text(
            'This app needs location permission to show you nearby restaurants. Would you like to grant permission?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                context.read<HomeBloc>().add(RequestLocationPermissionEvent());
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: kColorDarkBlue,
                foregroundColor: kColorWhite,
              ),
              child: const Text('Grant Permission'),
            ),
          ],
        );
      },
    );
  }

  void _showLocationDeniedSnackBar(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Location permission denied. You can enable it in settings.'),
        backgroundColor: Colors.orange,
      ),
    );
  }
}

