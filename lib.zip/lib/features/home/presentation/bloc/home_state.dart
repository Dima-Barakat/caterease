import 'package:equatable/equatable.dart';
import '../../domain/entities/restaurant.dart';
import '../../domain/entities/category.dart';
import '../../domain/entities/location.dart';

abstract class HomeState extends Equatable {
  const HomeState();

  @override
  List<Object?> get props => [];
}

class HomeInitial extends HomeState {}

class HomeLoading extends HomeState {}

class LocationPermissionRequested extends HomeState {}

class LocationPermissionDenied extends HomeState {}

class HomeLoaded extends HomeState {
  final List<Restaurant> restaurants;
  final List<Category> categories;
  final Location? currentLocation;

  const HomeLoaded({
    required this.restaurants,
    required this.categories,
    this.currentLocation,
  });

  @override
  List<Object?> get props => [restaurants, categories, currentLocation];

  HomeLoaded copyWith({
    List<Restaurant>? restaurants,
    List<Category>? categories,
    Location? currentLocation,
  }) {
    return HomeLoaded(
      restaurants: restaurants ?? this.restaurants,
      categories: categories ?? this.categories,
      currentLocation: currentLocation ?? this.currentLocation,
    );
  }
}

class HomeError extends HomeState {
  final String message;

  const HomeError(this.message);

  @override
  List<Object> get props => [message];
}

