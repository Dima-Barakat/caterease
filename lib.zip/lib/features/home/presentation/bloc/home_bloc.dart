import 'package:flutter_bloc/flutter_bloc.dart';
import '../../domain/usecases/get_nearby_restaurants.dart';
import '../../domain/usecases/get_categories.dart';
import '../../domain/usecases/get_current_location.dart';
import '../../domain/usecases/request_location_permission.dart';
import 'home_event.dart';
import 'home_state.dart';

class HomeBloc extends Bloc<HomeEvent, HomeState> {
  final GetNearbyRestaurants getNearbyRestaurants;
  final GetCategories getCategories;
  final GetCurrentLocation getCurrentLocation;
  final RequestLocationPermission requestLocationPermission;

  HomeBloc({
    required this.getNearbyRestaurants,
    required this.getCategories,
    required this.getCurrentLocation,
    required this.requestLocationPermission,
  }) : super(HomeInitial()) {
    on<LoadHomeData>(_onLoadHomeData);
    on<RequestLocationPermissionEvent>(_onRequestLocationPermission);
    on<RefreshRestaurants>(_onRefreshRestaurants);
    on<LoadRestaurantsByCategory>(_onLoadRestaurantsByCategory);
  }

  Future<void> _onLoadHomeData(
      LoadHomeData event, Emitter<HomeState> emit) async {
    emit(HomeLoading());

    try {
      // Load categories first
      final categories = await getCategories();

      // Try to get current location
      try {
        final location = await getCurrentLocation();
        final restaurants = await getNearbyRestaurants(location);

        emit(HomeLoaded(
          restaurants: restaurants,
          categories: categories,
          currentLocation: location,
        ));
      } catch (locationError) {
        // If location fails, still show categories but request permission
        emit(LocationPermissionRequested());
      }
    } catch (e) {
      emit(HomeError('Failed to load data: ${e.toString()}'));
    }
  }

  Future<void> _onRequestLocationPermission(
      RequestLocationPermissionEvent event, Emitter<HomeState> emit) async {
    try {
      final permissionGranted = await requestLocationPermission();

      if (permissionGranted) {
        // Permission granted, load home data
        add(LoadHomeData());
      } else {
        emit(LocationPermissionDenied());
      }
    } catch (e) {
      emit(HomeError('Failed to request location permission: ${e.toString()}'));
    }
  }

  Future<void> _onRefreshRestaurants(
      RefreshRestaurants event, Emitter<HomeState> emit) async {
    if (state is HomeLoaded) {
      final currentState = state as HomeLoaded;

      if (currentState.currentLocation != null) {
        try {
          final restaurants =
              await getNearbyRestaurants(currentState.currentLocation!);
          emit(currentState.copyWith(restaurants: restaurants));
        } catch (e) {
          emit(HomeError('Failed to refresh restaurants: ${e.toString()}'));
        }
      }
    }
  }

  Future<void> _onLoadRestaurantsByCategory(
      LoadRestaurantsByCategory event, Emitter<HomeState> emit) async {
    // This would be implemented if you have a specific use case for filtering by category
    // For now, we'll just refresh all restaurants
    add(RefreshRestaurants());
  }
}
