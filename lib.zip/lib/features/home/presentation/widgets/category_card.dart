import 'package:flutter/material.dart';
import '../../domain/entities/category.dart';
import '../../../../core/constants/colors.dart';

class CategoryCard extends StatelessWidget {
  final Category category;
  final VoidCallback? onTap;

  const CategoryCard({
    Key? key,
    required this.category,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 80,
        margin: const EdgeInsets.only(right: 12),
        child: Column(
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: kColorLightGray,
                borderRadius: BorderRadius.circular(12),
                image: category.imageUrl.isNotEmpty
                    ? DecorationImage(
                        image: NetworkImage(category.imageUrl),
                        fit: BoxFit.cover,
                      )
                    : null,
              ),
              child: category.imageUrl.isEmpty
                  ? const Icon(
                      Icons.restaurant,
                      color: kColorDarkBlue,
                      size: 30,
                    )
                  : null,
            ),
            const SizedBox(height: 8),
            Text(
              category.name,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w500,
                color: kColorDarkBlue,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

