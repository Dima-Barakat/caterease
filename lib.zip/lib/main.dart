import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'injection_container.dart' as di;
import 'features/home/presentation/bloc/home_bloc.dart';
import 'features/home/presentation/pages/home_page.dart';
import 'core/constants/colors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await di.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CaterEase',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: kColorDarkBlue,
          primary: kColorDarkBlue,
          secondary: kColorGreen,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
        appBarTheme: const AppBarTheme(
          backgroundColor: kColorWhite,
          foregroundColor: kColorDarkBlue,
          elevation: 0,
        ),
        scaffoldBackgroundColor: kColorWhite,
      ),
      home: BlocProvider(
        create: (context) => di.sl<HomeBloc>(),
        child: const HomePage(),
      ),
    );
  }
}

