import 'package:flutter/material.dart';

const kColorLightGray = Color(0xFFE6E6E6);
const kColorGreen     = Color(0xFFB7D6B7);
const kColorBlueGray  = Color(0xFFC0CCD8);
const kColorDarkBlue  = Color(0xFF314E76);
const kColorWhite     = Colors.white;

