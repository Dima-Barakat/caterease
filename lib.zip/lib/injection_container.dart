import 'package:get_it/get_it.dart';
import 'package:http/http.dart' as http;

import 'core/network/api_client.dart';
import 'features/home/data/datasources/restaurant_remote_datasource.dart';
import 'features/home/data/datasources/location_local_datasource.dart';
import 'features/home/data/repositories/restaurant_repository_impl.dart';
import 'features/home/data/repositories/location_repository_impl.dart';
import 'features/home/domain/repositories/restaurant_repository.dart';
import 'features/home/domain/repositories/location_repository.dart';
import 'features/home/domain/usecases/get_nearby_restaurants.dart';
import 'features/home/domain/usecases/get_categories.dart';
import 'features/home/domain/usecases/get_current_location.dart';
import 'features/home/domain/usecases/request_location_permission.dart';
import 'features/home/presentation/bloc/home_bloc.dart';

final sl = GetIt.instance;

Future<void> init() async {
  // Bloc
  sl.registerFactory(
    () => HomeBloc(
      getNearbyRestaurants: sl(),
      getCategories: sl(),
      getCurrentLocation: sl(),
      requestLocationPermission: sl(),
    ),
  );

  // Use cases
  sl.registerLazySingleton(() => GetNearbyRestaurants(sl()));
  sl.registerLazySingleton(() => GetCategories(sl()));
  sl.registerLazySingleton(() => GetCurrentLocation(sl()));
  sl.registerLazySingleton(() => RequestLocationPermission(sl()));

  // Repository
  sl.registerLazySingleton<RestaurantRepository>(
    () => RestaurantRepositoryImpl(remoteDataSource: sl()),
  );
  sl.registerLazySingleton<LocationRepository>(
    () => LocationRepositoryImpl(localDataSource: sl()),
  );

  // Data sources
  sl.registerLazySingleton<RestaurantRemoteDataSource>(
    () => RestaurantRemoteDataSourceImpl(apiClient: sl()),
  );
  sl.registerLazySingleton<LocationLocalDataSource>(
    () => LocationLocalDataSourceImpl(),
  );

  // Core
  sl.registerLazySingleton(() => ApiClient(client: sl()));

  // External
  sl.registerLazySingleton(() => http.Client());
}

