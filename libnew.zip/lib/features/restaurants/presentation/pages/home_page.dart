
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:caterease/features/restaurants/presentation/bloc/restaurants_bloc.dart';
import 'package:caterease/features/location/presentation/bloc/location_bloc.dart';
import 'package:caterease/features/restaurants/presentation/widgets/restaurant_card.dart';
import 'package:caterease/features/location/presentation/widgets/location_permission_widget.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  void initState() {
    super.initState();
    context.read<LocationBloc>().add(RequestLocationPermissionEvent());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('CaterEase'),
        centerTitle: true,
      ),
      body: BlocConsumer<LocationBloc, LocationState>(
        listener: (context, locationState) {
          if (locationState is LocationPermissionGranted) {
            context.read<LocationBloc>().add(GetCurrentLocationEvent());
          } else if (locationState is LocationLoaded) {
            context.read<RestaurantsBloc>().add(
                  LoadNearbyRestaurantsEvent(
                    latitude: locationState.position.latitude,
                    longitude: locationState.position.longitude,
                  ),
                );
          } else if (locationState is LocationError) {
            // If location permission is denied or location cannot be fetched, load all restaurants
            context.read<RestaurantsBloc>().add(LoadAllRestaurantsEvent());
          }
        },
        builder: (context, locationState) {
          if (locationState is LocationLoading) {
            return Center(child: CircularProgressIndicator());
          } else if (locationState is LocationError && locationState.message == "تم رفض إذن الموقع") {
            return LocationPermissionWidget();
          } else {
            return BlocBuilder<RestaurantsBloc, RestaurantsState>(
              builder: (context, restaurantsState) {
                if (restaurantsState is RestaurantsLoading) {
                  return Center(child: CircularProgressIndicator());
                } else if (restaurantsState is RestaurantsLoaded) {
                  return ListView.builder(
                    padding: const EdgeInsets.all(16.0),
                    itemCount: restaurantsState.restaurants.length,
                    itemBuilder: (context, index) {
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 16.0),
                        child: RestaurantCard(restaurant: restaurantsState.restaurants[index]),
                      );
                    },
                  );
                } else if (restaurantsState is RestaurantsError) {
                  return Center(child: Text(restaurantsState.message));
                } else {
                  return Center(child: Text('لا توجد مطاعم لعرضها.'));
                }
              },
            );
          }
        },
      ),
    );
  }
}


