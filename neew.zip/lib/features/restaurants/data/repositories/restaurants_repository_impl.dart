import "dart:convert";

import "package:caterease/features/restaurants/data/models/branch_model.dart";
import "package:dartz/dartz.dart";
import "package:http/http.dart" as http;
import "../../../../core/error/failures.dart";
import "../../domain/entities/restaurant.dart";
import "../datasources/restaurants_remote_data_source.dart";

class RestaurantsRepository {
  Future<List<BranchModel>> getBranchesByCategory(String category) async {
    final url =
        Uri.parse("http://192.168.43.2:8000/api/branches/category/$category");

    final response = await http.get(url);

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      final List branches = data['data'];
      return branches.map((e) => BranchModel.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load branches");
    }
  }
}

class RestaurantsRepositoryImpl implements RestaurantsRepository {
  final RestaurantsRemoteDataSource remoteDataSource;

  RestaurantsRepositoryImpl({required this.remoteDataSource});

  Future<Either<Failure, List<Restaurant>>> getNearbyRestaurants(
    double latitude,
    double longitude,
  ) async {
    try {
      final restaurants = await remoteDataSource.getNearbyRestaurants(
        latitude,
        longitude,
      );
      return Right(restaurants);
    } catch (e) {
      return Left(ServerFailure());
    }
  }

  Future<Either<Failure, List<Restaurant>>> getAllRestaurants() async {
    try {
      final restaurants = await remoteDataSource.getAllRestaurants();
      return Right(restaurants);
    } catch (e) {
      return Left(ServerFailure());
    }
  }

  @override
  Future<List<BranchModel>> getBranchesByCategory(String category) {
    // TODO: implement getBranchesByCategory
    throw UnimplementedError();
  }
}
