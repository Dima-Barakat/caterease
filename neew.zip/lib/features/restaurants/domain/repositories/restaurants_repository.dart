import "dart:convert";

import "package:caterease/features/restaurants/data/models/branch_model.dart";
import "package:dartz/dartz.dart";
import "package:http/http.dart" as http;
import "../../../../core/error/failures.dart";
import "../entities/restaurant.dart";

abstract class RestaurantsRepository {
  Future<Either<Failure, List<Restaurant>>> getNearbyRestaurants(
    double latitude,
    double longitude,
  );

  Future<Either<Failure, List<Restaurant>>> getAllRestaurants();
}

Future<List<BranchModel>> getBranchesByCategory(String category) async {
  final response = await http
      .get(Uri.parse("http://localhost:8000/api/branches/category/$category"));

  if (response.statusCode == 200) {
    final jsonData = json.decode(response.body);
    final List<dynamic> branchesJson = jsonData['data'];

    return branchesJson.map((json) => BranchModel.fromJson(json)).toList();
  } else {
    throw Exception('Failed to fetch restaurants');
  }
}
