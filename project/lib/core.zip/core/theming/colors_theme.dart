
import 'dart:ui';

class ColorsTheme {
  static const Color lightGray = Color(0xFFE6E6E6);
  static const Color lightGreen = Color(0xFFB7D6B7);
  static const Color darkBlue = Color(0xFF314E76);
  static const Color lightBlue = Color(0xFFC0CCD8);
}